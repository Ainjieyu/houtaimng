<template>
    <h3>MALL</h3>
</template>
<script>
</script>