<script setup>
import { useStore } from "vuex";
import {useRouter} from "vue-router"
const store = useStore();
const router = useRouter();
store.commit("addMenu",router);
</script>

<template>
  <router-view />
</template>

